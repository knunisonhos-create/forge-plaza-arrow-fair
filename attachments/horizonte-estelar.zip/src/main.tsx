import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import {ErrorBoundary} from './components/ErrorBoundary.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <ErrorBoundary
    fallbackTitle="Horizonte Estelar — Recuperação de Sessão"
    onReset={() => window.location.reload()}
  >
    <App />
  </ErrorBoundary>
);
