import express from 'express';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const CACHE_DIR = path.resolve(process.cwd(), '.cache', 'cards');

if (!fs.existsSync(CACHE_DIR)) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

function getSafeCachePath(cardId: string): string | null {
  if (!/^[a-z0-9_-]{1,64}$/i.test(cardId)) {
    return null;
  }
  const resolved = path.resolve(CACHE_DIR, `${cardId}.json`);
  if (!resolved.startsWith(CACHE_DIR + path.sep)) {
    return null;
  }
  return resolved;
}

function getGenAIClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/api/card-image/:cardId', (req, res) => {
    const safePath = getSafeCachePath(String(req.params.cardId || ''));
    if (!safePath) {
      res.status(400).json({ error: 'Identificador de card inválido.' });
      return;
    }
    if (!fs.existsSync(safePath)) {
      res.status(404).json({ cached: false });
      return;
    }
    try {
      const raw = fs.readFileSync(safePath, 'utf-8');
      const parsed = JSON.parse(raw) as { imageUrl?: string; model?: string; createdAt?: number };
      res.json({ cached: true, ...parsed });
    } catch {
      res.status(500).json({ error: 'Falha ao ler cache local do card.' });
    }
  });

  app.post('/api/card-image', async (req, res) => {
    const body = req.body as {
      cardId?: unknown;
      kind?: unknown;
      name?: unknown;
      lifeForm?: unknown;
      description?: unknown;
      regenerate?: unknown;
    };

    const cardId = typeof body?.cardId === 'string' ? body.cardId.trim() : '';
    const safePath = getSafeCachePath(cardId);
    if (!safePath) {
      res.status(400).json({ error: 'Identificador de card inválido.', code: 'INVALID_ID' });
      return;
    }

    const regenerate = body?.regenerate === true;
    if (!regenerate && fs.existsSync(safePath)) {
      try {
        const raw = fs.readFileSync(safePath, 'utf-8');
        const parsed = JSON.parse(raw) as { imageUrl?: string; model?: string; createdAt?: number };
        if (parsed.imageUrl) {
          res.json({ cached: true, imageUrl: parsed.imageUrl, model: parsed.model });
          return;
        }
      } catch {
        // Proceed to regenerate if cache file is corrupted
      }
    }

    const ai = getGenAIClient();
    if (!ai) {
      res.status(503).json({
        error: 'Chave de API Gemini não configurada no servidor (Settings > Secrets). O desenho vetorial padrão continua ativo.',
        code: 'MISSING_API_KEY',
        retryable: true,
      });
      return;
    }

    const kind = body?.kind === 'species' ? 'intelligent alien species portrait' : 'alien planetary creature specimen';
    const name = typeof body?.name === 'string' ? body.name.slice(0, 80) : 'Unknown Organism';
    const lifeForm = typeof body?.lifeForm === 'string' ? body.lifeForm.slice(0, 60) : 'Alien';
    const description = typeof body?.description === 'string' ? body.description.slice(0, 220) : '';

    const prompt = [
      `Crisp 16-bit retro sci-fi pixel art card illustration, centered ${kind}.`,
      `Subject: "${name}" (${lifeForm}).`,
      description ? `Traits: ${description}.` : '',
      'Dark cosmic obsidian background (#070b14), sharp unblurred pixels, clean silhouette, vibrant xenobiology palette, no text, no watermark, no frame borders.',
    ]
      .filter(Boolean)
      .join(' ');

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: {
          parts: [{ text: prompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: '1:1',
          },
        },
      });

      let imageUrl = '';
      const parts = response.candidates?.[0]?.content?.parts ?? [];
      for (const part of parts) {
        if (part.inlineData?.data) {
          const mime = part.inlineData.mimeType ?? 'image/png';
          imageUrl = `data:${mime};base64,${part.inlineData.data}`;
          break;
        }
      }

      if (!imageUrl) {
        res.status(502).json({
          error: 'O modelo não retornou imagem válida para este card.',
          code: 'EMPTY_IMAGE',
          retryable: true,
        });
        return;
      }

      const payload = {
        imageUrl,
        model: 'gemini-3.1-flash-lite-image',
        createdAt: Date.now(),
      };
      fs.writeFileSync(safePath, JSON.stringify(payload), 'utf-8');
      res.json({ cached: false, ...payload });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      const lower = message.toLowerCase();
      const isQuota = lower.includes('429') || lower.includes('quota') || lower.includes('resource_exhausted');
      const isAuth = lower.includes('403') || lower.includes('401') || lower.includes('api_key') || lower.includes('permission_denied');

      if (isQuota) {
        res.status(429).json({
          error: 'Cota de geração de imagem atingida no momento. Tente novamente mais tarde.',
          code: 'QUOTA_EXCEEDED',
          retryable: true,
        });
        return;
      }
      if (isAuth) {
        res.status(403).json({
          error: 'Chave de API inválida ou sem permissão para modelo de imagem pago (Settings > Secrets).',
          code: 'AUTH_ERROR',
          retryable: true,
        });
        return;
      }
      res.status(500).json({
        error: 'Erro ao gerar imagem pixel art no servidor.',
        code: 'GENERATION_FAILED',
        retryable: true,
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Horizonte Estelar server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
